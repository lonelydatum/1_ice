import {init} from '../../_common/js/common.js'



init()


