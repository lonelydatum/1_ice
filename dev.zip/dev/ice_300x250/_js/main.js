import {init} from '../../_common/js/common.js'



init(1.8)


